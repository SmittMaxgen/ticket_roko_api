// // controllers/adminEventController.js
// const Event = require("../../models/event/EventModel");
// const User = require("../../models/user/UserModel");
// const Category = require("../../models/category/CategoryModel");
// const Hall = require("../../models/hall/HallModel");
// const { Op } = require("sequelize");

// // Reusable include
// const baseInclude = [
//   {
//     model: User,
//     as: "organizer",
//     attributes: ["id", "name", "email"],
//   },
//   {
//     model: Category,
//     as: "category",
//     attributes: ["id", "name"],
//   },
//   {
//     model: Hall,
//     as: "hall",
//     attributes: ["id", "name"],
//   },
// ];

// // GET /api/events

// exports.getAllEvents = async (req, res) => {
//   try {
//     let { page = 1, limit = 20, status, search, category_id } = req.query;

//     // =========================
//     // VALIDATION
//     // =========================
//     page = Number(page);
//     limit = Number(limit);

//     if (!Number.isInteger(page) || page < 1) {
//       return res.status(400).json({
//         success: false,
//         message: "page must be a positive integer",
//       });
//     }

//     if (!Number.isInteger(limit) || limit < 1 || limit > 100) {
//       return res.status(400).json({
//         success: false,
//         message: "limit must be between 1 and 100",
//       });
//     }

//     const offset = (page - 1) * limit;

//     const where = {};

//     if (status) {
//       const allowedStatus = ["draft", "pending", "approved", "rejected"];
//       if (!allowedStatus.includes(status)) {
//         return res.status(400).json({
//           success: false,
//           message: `Invalid status. Allowed: ${allowedStatus.join(", ")}`,
//         });
//       }
//       where.status = status;
//     }

//     if (category_id) {
//       const catId = Number(category_id);
//       if (isNaN(catId)) {
//         return res.status(400).json({
//           success: false,
//           message: "category_id must be a number",
//         });
//       }
//       where.category_id = catId;
//     }

//     if (search && search.trim() !== "") {
//       where.title = {
//         [Op.like]: `%${search.trim()}%`,
//       };
//     }

//     // =========================
//     // QUERY
//     // =========================
//     const { rows, count } = await Event.findAndCountAll({
//       where,
//       include: [
//         {
//           model: Category,
//           attributes: ["id", "name"],
//         },
//         {
//           model: User,
//           as: "organizer",
//           attributes: ["id", "name", "email"],
//         },
//         {
//           model: Hall,
//           attributes: ["id", "name", "city"],
//         },
//       ],
//       limit,
//       offset,
//       order: [["created_at", "DESC"]],
//       distinct: true,
//     });

//     return res.json({
//       success: true,
//       data: rows,
//       pagination: {
//         total: count,
//         page,
//         limit,
//         totalPages: Math.ceil(count / limit),
//       },
//     });
//   } catch (error) {
//     console.error("❌ Get Events Error:", error);

//     return res.status(500).json({
//       success: false,
//       message: error.message, // IMPORTANT: show real error
//     });
//   }
// };
// // GET /api/events/:id
// exports.getEventById = async (req, res) => {
//   try {
//     const event = await Event.findByPk(req.params.id, {
//       include: baseInclude,
//     });

//     if (!event) {
//       return res.status(404).json({
//         success: false,
//         message: "Event not found",
//       });
//     }

//     return res.json({
//       success: true,
//       data: event,
//     });
//   } catch (error) {
//     return res.status(500).json({
//       success: false,
//       message: "Server error",
//     });
//   }
// };

// // POST /api/events
// exports.createEvent = async (req, res) => {
//   try {
//     const {
//       organizer_id,
//       hall_id,
//       category_id,
//       title,
//       description,
//       event_date,
//       start_time,
//       end_time,
//       city,
//       address,
//       ticket_price = 0,
//       total_tickets = 0,
//       is_free = false,
//     } = req.body;

//     // =========================
//     // VALIDATION
//     // =========================

//     if (!title || title.trim() === "") {
//       return res.status(400).json({
//         success: false,
//         message: "title is required",
//       });
//     }

//     if (!hall_id) {
//       return res.status(400).json({
//         success: false,
//         message: "hall_id is required",
//       });
//     }

//     if (!category_id) {
//       return res.status(400).json({
//         success: false,
//         message: "category_id is required",
//       });
//     }

//     if (!event_date) {
//       return res.status(400).json({
//         success: false,
//         message: "event_date is required",
//       });
//     }

//     if (!start_time || !end_time) {
//       return res.status(400).json({
//         success: false,
//         message: "start_time and end_time are required",
//       });
//     }

//     if (!city || city.trim() === "") {
//       return res.status(400).json({
//         success: false,
//         message: "city is required",
//       });
//     }

//     if (!address || address.trim() === "") {
//       return res.status(400).json({
//         success: false,
//         message: "address is required",
//       });
//     }

//     // =========================
//     // TYPE VALIDATION
//     // =========================

//     if (isNaN(hall_id)) {
//       return res.status(400).json({
//         success: false,
//         message: "hall_id must be a number",
//       });
//     }

//     if (isNaN(category_id)) {
//       return res.status(400).json({
//         success: false,
//         message: "category_id must be a number",
//       });
//     }

//     if (isNaN(ticket_price) || ticket_price < 0) {
//       return res.status(400).json({
//         success: false,
//         message: "ticket_price must be a valid number",
//       });
//     }

//     if (isNaN(total_tickets) || total_tickets < 0) {
//       return res.status(400).json({
//         success: false,
//         message: "total_tickets must be a valid number",
//       });
//     }

//     // Date validation
//     const date = new Date(event_date);
//     if (isNaN(date.getTime())) {
//       return res.status(400).json({
//         success: false,
//         message: "invalid event_date format",
//       });
//     }

//     // =========================
//     // SLUG GENERATION
//     // =========================

//     const slug =
//       title
//         .toLowerCase()
//         .trim()
//         .replace(/\s+/g, "-")
//         .replace(/[^a-z0-9-]/g, "") +
//       "-" +
//       Date.now();

//     // =========================
//     // CREATE EVENT
//     // =========================

//     const event = await Event.create({
//       organizer_id: req.user?.id || organizer_id,
//       hall_id,
//       category_id,
//       title: title.trim(),
//       slug,
//       description,
//       event_date,
//       start_time,
//       end_time,
//       city: city.trim(),
//       address: address.trim(),
//       ticket_price,
//       total_tickets,
//       is_free: Boolean(is_free),
//       status: "approved",
//     });

//     return res.status(201).json({
//       success: true,
//       message: "Event created successfully",
//       data: {
//         id: event.id,
//         slug: event.slug,
//       },
//     });
//   } catch (error) {
//     console.error("Create Event Error:", error);

//     return res.status(500).json({
//       success: false,
//       message: error.message || "Server error",
//     });
//   }
// };

// // PUT /api/events/:id
// exports.updateEvent = async (req, res) => {
//   try {
//     const event = await Event.findByPk(req.params.id);

//     if (!event) {
//       return res.status(404).json({
//         success: false,
//         message: "Event not found",
//       });
//     }

//     await event.update(req.body);

//     return res.json({
//       success: true,
//       message: "Event updated",
//     });
//   } catch (error) {
//     return res.status(500).json({
//       success: false,
//       message: "Server error",
//     });
//   }
// };

// // PATCH /api/events/:id/approve
// exports.approveEvent = async (req, res) => {
//   await Event.update(
//     {
//       status: "approved",
//       published_at: new Date(),
//     },
//     {
//       where: { id: req.params.id },
//     },
//   );

//   return res.json({
//     success: true,
//     message: "Event approved & published",
//   });
// };

// // PATCH /api/events/:id/reject
// exports.rejectEvent = async (req, res) => {
//   const { reason } = req.body;

//   await Event.update(
//     {
//       status: "rejected",
//       rejection_reason: reason,
//     },
//     {
//       where: { id: req.params.id },
//     },
//   );

//   return res.json({
//     success: true,
//     message: "Event rejected",
//   });
// };

// // PATCH /api/events/:id/cancel
// exports.cancelEvent = async (req, res) => {
//   await Event.update(
//     {
//       status: "cancelled",
//     },
//     {
//       where: { id: req.params.id },
//     },
//   );

//   return res.json({
//     success: true,
//     message: "Event cancelled",
//   });
// };

// // DELETE /api/events/:id
// exports.deleteEvent = async (req, res) => {
//   await Event.destroy({
//     where: { id: req.params.id },
//   });

//   return res.json({
//     success: true,
//     message: "Event deleted",
//   });
// };

// // GET /api/events/stats/summary
// exports.getSummaryStats = async (req, res) => {
//   try {
//     const total = await Event.count();
//     const pending = await Event.count({
//       where: { status: "pending_approval" },
//     });
//     const approved = await Event.count({ where: { status: "approved" } });
//     const rejected = await Event.count({ where: { status: "rejected" } });
//     const cancelled = await Event.count({ where: { status: "cancelled" } });
//     const completed = await Event.count({ where: { status: "completed" } });

//     const sold = await Event.sum("sold_tickets");
//     const revenue = await Event.sum("ticket_price");

//     return res.json({
//       success: true,
//       data: {
//         total,
//         pending,
//         approved,
//         rejected,
//         cancelled,
//         completed,
//         total_sold: sold || 0,
//         total_revenue: revenue || 0,
//       },
//     });
//   } catch (error) {
//     return res.status(500).json({
//       success: false,
//       message: "Server error",
//     });
//   }
// };

// controllers/event/eventController.js

const { Op } = require("sequelize");

const Event = require("../../models/event/EventModel");
const User = require("../../models/user/UserModel");
const Category = require("../../models/category/CategoryModel");
const Hall = require("../../models/hall/HallModel");
const Seat = require("../../models/hall/HallSeatModel");
const BookingSeat = require("../../models/booking/BookingSeatModel");
const { Booking } = require("../../models");
const EventSectionPrice = require("../../models/event/EventSectionPriceModel");
const { sequelize } = require("../../config/db");

// ─────────────────────────────────────────────
// Reusable include
// ─────────────────────────────────────────────
const baseInclude = [
  {
    model: User,
    as: "organizer",
    attributes: ["id", "name", "email"],
  },
  {
    model: Category,
    attributes: ["id", "name"],
  },
  {
    model: Hall,
    attributes: ["id", "name", "city"],
  },
];

// ─────────────────────────────────────────────
// GET /api/events
// ─────────────────────────────────────────────
// exports.getAllEvents = async (req, res) => {
//   try {
//     let { page = 1, limit = 20, status, search, category_id } = req.query;

//     page = Number(page);
//     limit = Number(limit);

//     const offset = (page - 1) * limit;

//     const where = {};

//     if (status) where.status = status;

//     if (category_id) where.category_id = Number(category_id);

//     if (search) {
//       where.title = {
//         [Op.like]: `%${search.trim()}%`,
//       };
//     }

//     const { rows, count } = await Event.findAndCountAll({
//       where,
//       include: baseInclude,
//       as: "events",
//       order: [["created_at", "DESC"]],
//       limit,
//       offset,
//       distinct: true,
//     });

//     return res.json({
//       success: true,
//       data: rows,
//       pagination: {
//         total: count,
//         page,
//         limit,
//         totalPages: Math.ceil(count / limit),
//       },
//     });
//   } catch (error) {
//     console.error(error);

//     return res.status(500).json({
//       success: false,
//       message: error.message,
//     });
//   }
// };

exports.getAllEvents = async (req, res) => {
  try {
    let { page = 1, limit = 20, status, search, category_id } = req.query;

    page = Number(page);
    limit = Number(limit);

    const offset = (page - 1) * limit;

    const where = {};

    if (status) where.status = status;
    if (category_id) where.category_id = Number(category_id);

    if (search) {
      where.title = {
        [Op.like]: `%${search.trim()}%`,
      };
    }

    const { rows, count } = await Event.findAndCountAll({
      where,

      include: [
        {
          model: Hall,
          as: "hall",
        },
        {
          model: Category,
        },
        {
          model: User,
          as: "organizer",
        },
      ],

      order: [["created_at", "DESC"]],
      limit,
      offset,
      distinct: true,
    });

    return res.json({
      success: true,
      data: rows,
      pagination: {
        total: count,
        page,
        limit,
        totalPages: Math.ceil(count / limit),
      },
    });
  } catch (error) {
    console.error(error);

    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};
// ─────────────────────────────────────────────
// GET /api/events/:id
// BASIC EVENT DETAIL
// ─────────────────────────────────────────────
// exports.getEventById = async (req, res) => {
//   try {
//     const event = await Event.findByPk(req.params.id, {
//       include: baseInclude,
//     });

//     if (!event) {
//       return res.status(404).json({
//         success: false,
//         message: "Event not found",
//       });
//     }

//     return res.json({
//       success: true,
//       data: event,
//     });
//   } catch (error) {
//     return res.status(500).json({
//       success: false,
//       message: error.message,
//     });
//   }
// };

exports.getEventById = async (req, res) => {
  try {
    const event = await Event.findByPk(req.params.id, {
      include: [
        ...baseInclude,
        { model: EventSectionPrice, as: "sectionPrices" },
      ],
    });

    if (!event) {
      return res
        .status(404)
        .json({ success: false, message: "Event not found" });
    }

    return res.json({ success: true, data: event });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};
// ─────────────────────────────────────────────
// ⭐ GET /api/events/:id/booking-layout
// THIS IS WHAT YOU NEED FOR FRONTEND
// ─────────────────────────────────────────────
// exports.getBookingLayout = async (req, res) => {
//   try {
//     const eventId = req.params.id;

//     const event = await Event.findByPk(eventId, {
//       include: [
//         {
//           model: Hall,
//           attributes: ["id", "name", "city"],
//         },
//       ],
//     });

//     if (!event) {
//       return res.status(404).json({
//         success: false,
//         message: "Event not found",
//       });
//     }

//     // All hall seats
//     const seats = await Seat.findAll({
//       where: {
//         hall_id: event.hall_id,
//         is_active: true,
//       },
//       order: [
//         ["sort_order", "ASC"],
//         ["id", "ASC"],
//       ],
//     });

//     // Booked seats for this event only
//     // const booked = await BookingSeat.findAll({
//     //   where: {
//     //     event_id: eventId,
//     //     status: "booked",
//     //   },
//     //   attributes: ["seat_id"],
//     // });

//     const booked = await BookingSeat.findAll({
//       where: {
//         event_id: eventId,
//       },
//       include: [
//         {
//           model: Booking,
//           attributes: ["id", "booking_ref", "status"],
//           include: [
//             {
//               model: User,
//               as: "user",
//               attributes: ["id", "name", "email", "phone"],
//             },
//           ],
//         },
//       ],
//     });
//     const seatMap = new Map();

//     booked.forEach((bs) => {
//       if (!bs.Booking) return;

//       seatMap.set(Number(bs.seat_id), {
//         booking_id: bs.Booking.id,
//         booking_ref: bs.Booking.booking_ref,
//         status: bs.Booking.status,

//         // 🔥 FIX HERE
//         user: bs.Booking.user || null,
//       });
//     });
//     const bookedSeatIds = booked.map((x) => Number(x.seat_id));

//     // merge seat status
//     // const finalSeats = seats.map((seat) => {
//     //   const plain = seat.toJSON();

//     //   return {
//     //     ...plain,
//     //     status: bookedSeatIds.includes(seat.id)
//     //       ? "sold"
//     //       : seat.is_space
//     //         ? "space"
//     //         : "available",
//     //   };
//     // });
//     const finalSeats = seats.map((seat) => {
//       const plain = seat.toJSON();

//       const bookingInfo = seatMap.get(seat.id);

//       return {
//         ...plain,

//         status: bookingInfo ? "sold" : seat.is_space ? "space" : "available",

//         booking: bookingInfo || null,
//       };
//     });

//     return res.json({
//       success: true,
//       data: {
//         event,
//         hall: event.Hall,
//         seats: finalSeats,
//         bookedSeatIds,
//         totalSeats: finalSeats.filter((x) => !x.is_space).length,
//         soldSeats: bookedSeatIds.length,
//         availableSeats:
//           finalSeats.filter((x) => !x.is_space).length - bookedSeatIds.length,
//       },
//     });
//   } catch (error) {
//     console.error(error);

//     return res.status(500).json({
//       success: false,
//       message: error.message,
//     });
//   }
// };
exports.getBookingLayout = async (req, res) => {
  try {
    const eventId = req.params.id;

    const event = await Event.findByPk(eventId, {
      include: [
        {
          model: Hall,
          as: "hall",
          attributes: ["id", "name", "city"],
        },
      ],
    });

    if (!event) {
      return res.status(404).json({
        success: false,
        message: "Event not found",
      });
    }

    const seats = await Seat.findAll({
      where: {
        hall_id: event.hall_id,
        is_active: true,
      },
      order: [
        ["sort_order", "ASC"],
        ["id", "ASC"],
      ],
    });

    const booked = await BookingSeat.findAll({
      where: {
        event_id: eventId,
      },
      include: [
        {
          model: Booking,
          as: "Booking",
          attributes: ["id", "booking_ref", "status"],
          include: [
            {
              model: User,
              as: "user",
              attributes: ["id", "name", "email", "phone"],
            },
          ],
        },
      ],
    });

    const seatMap = new Map();

    booked.forEach((bs) => {
      if (!bs.Booking) return;

      seatMap.set(Number(bs.seat_id), {
        booking_id: bs.Booking.id,
        booking_ref: bs.Booking.booking_ref,
        status: bs.Booking.status,
        user: bs.Booking.user || null,
      });
    });

    const bookedSeatIds = booked.map((x) => Number(x.seat_id));

    // const finalSeats = seats.map((seat) => {
    //   const plain = seat.toJSON();
    //   const bookingInfo = seatMap.get(seat.id);

    //   return {
    //     ...plain,
    //     status: bookingInfo ? "sold" : seat.is_space ? "space" : "available",
    //     booking: bookingInfo || null,
    //   };
    // });

    // Fetch event-specific section prices
    const sectionPriceRows = await EventSectionPrice.findAll({
      where: { event_id: eventId },
    });
    const sectionPriceMap = {};
    sectionPriceRows.forEach((sp) => {
      sectionPriceMap[sp.section_label] = Number(sp.price);
    });

    const finalSeats = seats.map((seat) => {
      const plain = seat.toJSON();
      const bookingInfo = seatMap.get(seat.id);

      // Override price with event section price if set
      const eventPrice = sectionPriceMap[plain.section_label];

      return {
        ...plain,
        price: eventPrice !== undefined ? eventPrice : plain.price,
        status: bookingInfo ? "sold" : seat.is_space ? "space" : "available",
        booking: bookingInfo || null,
      };
    });

    return res.json({
      success: true,
      data: {
        event,
        hall: event.hall,
        seats: finalSeats,
        bookedSeatIds,
        totalSeats: finalSeats.filter((x) => !x.is_space).length,
        soldSeats: bookedSeatIds.length,
        availableSeats:
          finalSeats.filter((x) => !x.is_space).length - bookedSeatIds.length,
      },
    });
  } catch (error) {
    console.error(error);

    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};
exports.getEventBookings = async (req, res) => {
  const eventId = req.params.id;

  const bookings = await Booking.findAll({
    where: { event_id: eventId },
    order: [["booked_at", "DESC"]], // ✅ FIXED
  });

  res.json({
    success: true,
    data: bookings,
  });
};

// ─────────────────────────────────────────────
// POST /api/events
// ─────────────────────────────────────────────
// exports.createEvent = async (req, res) => {
//   try {
//     const {
//       organizer_id,
//       hall_id,
//       category_id,
//       title,
//       description,
//       event_date,
//       start_time,
//       end_time,
//       city,
//       address,
//       ticket_price = 0,
//       total_tickets = 0,
//       is_free = false,
//     } = req.body;

//     const slug =
//       title
//         .toLowerCase()
//         .trim()
//         .replace(/\s+/g, "-")
//         .replace(/[^a-z0-9-]/g, "") +
//       "-" +
//       Date.now();

//     const event = await Event.create({
//       organizer_id: req.user?.id || organizer_id,
//       hall_id,
//       category_id,
//       title,
//       slug,
//       description,
//       event_date,
//       start_time,
//       end_time,
//       city,
//       address,
//       ticket_price,
//       total_tickets,
//       is_free,
//       status: "approved",
//     });

//     return res.status(201).json({
//       success: true,
//       message: "Event created",
//       data: event,
//     });
//   } catch (error) {
//     return res.status(500).json({
//       success: false,
//       message: error.message,
//     });
//   }
// };
exports.createEvent = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const {
      organizer_id,
      hall_id,
      category_id,
      title,
      description,
      event_date,
      start_time,
      end_time,
      city,
      address,
      ticket_price = 0,
      total_tickets = 0,
      is_free = false,
      section_prices = [], // [{ section_label, price }]
    } = req.body;

    const slug =
      title
        .toLowerCase()
        .trim()
        .replace(/\s+/g, "-")
        .replace(/[^a-z0-9-]/g, "") +
      "-" +
      Date.now();

    const event = await Event.create(
      {
        organizer_id: req.user?.id || organizer_id,
        hall_id,
        category_id,
        title,
        slug,
        description,
        event_date,
        start_time,
        end_time,
        city,
        address,
        ticket_price,
        total_tickets,
        is_free,
        status: "approved",
      },
      { transaction: t },
    );

    // Save per-section prices if provided
    if (section_prices.length > 0) {
      await EventSectionPrice.bulkCreate(
        section_prices.map((sp) => ({
          event_id: event.id,
          section_label: sp.section_label,
          price: Number(sp.price) || 0,
        })),
        { transaction: t },
      );
    }

    await t.commit();
    return res
      .status(201)
      .json({ success: true, message: "Event created", data: event });
  } catch (error) {
    await t.rollback();
    return res.status(500).json({ success: false, message: error.message });
  }
};
// ─────────────────────────────────────────────
// PUT /api/events/:id
// ─────────────────────────────────────────────
// exports.updateEvent = async (req, res) => {
//   try {
//     const event = await Event.findByPk(req.params.id);

//     if (!event) {
//       return res.status(404).json({
//         success: false,
//         message: "Event not found",
//       });
//     }

//     await event.update(req.body);

//     return res.json({
//       success: true,
//       message: "Event updated",
//     });
//   } catch (error) {
//     return res.status(500).json({
//       success: false,
//       message: error.message,
//     });
//   }
// };

exports.updateEvent = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const event = await Event.findByPk(req.params.id);
    if (!event) {
      await t.rollback();
      return res
        .status(404)
        .json({ success: false, message: "Event not found" });
    }

    const { section_prices = [], ...eventData } = req.body;

    await event.update(eventData, { transaction: t });

    // Update section prices — delete old, insert new
    if (section_prices.length > 0) {
      await EventSectionPrice.destroy({
        where: { event_id: event.id },
        transaction: t,
      });
      await EventSectionPrice.bulkCreate(
        section_prices.map((sp) => ({
          event_id: event.id,
          section_label: sp.section_label,
          price: Number(sp.price) || 0,
        })),
        { transaction: t },
      );
    }

    await t.commit();
    return res.json({ success: true, message: "Event updated" });
  } catch (error) {
    await t.rollback();
    return res.status(500).json({ success: false, message: error.message });
  }
};
// ─────────────────────────────────────────────
// PATCH /api/events/:id/approve
// ─────────────────────────────────────────────
exports.approveEvent = async (req, res) => {
  await Event.update(
    {
      status: "approved",
      published_at: new Date(),
    },
    {
      where: { id: req.params.id },
    },
  );

  return res.json({
    success: true,
    message: "Approved",
  });
};

// ─────────────────────────────────────────────
// PATCH /api/events/:id/reject
// ─────────────────────────────────────────────
exports.rejectEvent = async (req, res) => {
  await Event.update(
    {
      status: "rejected",
      rejection_reason: req.body.reason,
    },
    {
      where: { id: req.params.id },
    },
  );

  return res.json({
    success: true,
    message: "Rejected",
  });
};

// ─────────────────────────────────────────────
// PATCH /api/events/:id/cancel
// ─────────────────────────────────────────────
exports.cancelEvent = async (req, res) => {
  await Event.update(
    {
      status: "cancelled",
    },
    {
      where: { id: req.params.id },
    },
  );

  return res.json({
    success: true,
    message: "Cancelled",
  });
};

// ─────────────────────────────────────────────
// DELETE /api/events/:id
// ─────────────────────────────────────────────
exports.deleteEvent = async (req, res) => {
  await Event.destroy({
    where: { id: req.params.id },
  });

  return res.json({
    success: true,
    message: "Deleted",
  });
};

// ─────────────────────────────────────────────
// GET /api/events/stats/summary/all
// ─────────────────────────────────────────────
exports.getSummaryStats = async (req, res) => {
  try {
    const total = await Event.count();
    const approved = await Event.count({
      where: { status: "approved" },
    });

    const sold = await Event.sum("sold_tickets");

    return res.json({
      success: true,
      data: {
        total,
        approved,
        total_sold: sold || 0,
      },
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};
